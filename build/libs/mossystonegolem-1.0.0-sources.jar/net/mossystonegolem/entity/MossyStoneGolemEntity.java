package net.mossystonegolem.entity;

import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1330;
import net.minecraft.class_1347;
import net.minecraft.class_1352;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1427;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.entity.ai.goal.*;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.EnumSet;
import java.util.List;

public class MossyStoneGolemEntity extends class_1427 implements GeoEntity {
    private static final class_2940<Boolean> ATTACKING = class_2945.method_12791(MossyStoneGolemEntity.class, class_2943.field_13323);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    public final VerletChain chain = new VerletChain();

    public MossyStoneGolemEntity(class_1299<? extends class_1427> entityType, class_1937 world) {
        super(entityType, world);
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 300.0)
                .method_26868(class_5134.field_23718, 1.0)
                .method_26868(class_5134.field_23719, 0.15)
                .method_26868(class_5134.field_23721, 24.0)
                .method_26868(class_5134.field_23717, 32.0)
                .method_26868(class_5134.field_47761, 1.0);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(ATTACKING, false);
    }

    public boolean method_6510() {
        return this.field_6011.method_12789(ATTACKING);
    }

    public void method_19540(boolean attacking) {
        this.field_6011.method_12778(ATTACKING, attacking);
    }

    @Override
    public class_4048 method_55694(class_4050 pose) {
        return class_4048.method_18384(1.95f, 2.2f).method_55685(1.8f);
    }

    @Override
    protected class_1330 method_5963() {
        return new SluggishBodyControl(this);
    }

    @Override
    public void method_5773() {
        super.method_5773();

        // Verlet physics simulation for dragging chain and bell
        double yawRad = Math.toRadians(this.field_6283);
        double backDist = 0.45;
        double anchorX = this.method_23317() + Math.sin(yawRad) * backDist;
        double anchorY = this.method_23318() + 1.625;
        double anchorZ = this.method_23321() - Math.cos(yawRad) * backDist;

        this.chain.tick(this.method_37908(), new class_243(anchorX, anchorY, anchorZ), this.field_6283);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(1, new class_1347(this));
        this.field_6201.method_6277(2, new GolemSlamAttackGoal(this));
        this.field_6201.method_6277(3, new class_1394(this, 0.85));
        this.field_6201.method_6277(4, new class_1361(this, class_1657.class, 10.0f));
        this.field_6201.method_6277(5, new class_1376(this));

        this.field_6185.method_6277(1, new class_1399(this));
        this.field_6185.method_6277(2, new class_1400<>(this, class_1588.class, true));
    }

    public void performGroundSlam() {
        class_1937 world = this.method_37908();
        double forwardDist = 2.2;
        double rad = Math.toRadians(this.method_36454());
        double impactX = this.method_23317() - Math.sin(rad) * forwardDist;
        double impactY = this.method_23318();
        double impactZ = this.method_23321() + Math.cos(rad) * forwardDist;

        // Sounds
        world.method_43128(null, impactX, impactY, impactZ, class_3417.field_15152.comp_349(), class_3419.field_15251, 1.4f, 0.55f);
        world.method_43128(null, impactX, impactY, impactZ, class_3417.field_15026, class_3419.field_15251, 2.5f, 0.5f);
        world.method_43128(null, impactX, impactY, impactZ, class_3417.field_14833, class_3419.field_15251, 1.0f, 0.6f);

        // Particles: block.mossy_stone_bricks.break shockwave ring
        if (world instanceof class_3218 serverWorld) {
            class_2680 mossyBricks = class_2246.field_10065.method_9564();
            for (int i = 0; i < 36; i++) {
                double angle = (i / 36.0) * Math.PI * 2.0;
                double r = 1.0 + world.field_9229.method_43058() * 2.5;
                double px = impactX + Math.cos(angle) * r;
                double pz = impactZ + Math.sin(angle) * r;
                serverWorld.method_14199(new class_2388(class_2398.field_11217, mossyBricks), px, impactY + 0.1, pz, 4, 0.2, 0.3, 0.2, 0.15);
                serverWorld.method_14199(class_2398.field_17430, px, impactY + 0.1, pz, 1, 0.1, 0.1, 0.1, 0.05);
            }
        }

        // AoE Damage & Knockback
        class_238 aoeBox = new class_238(impactX - 3.5, impactY - 1.0, impactZ - 3.5, impactX + 3.5, impactY + 2.5, impactZ + 3.5);
        List<class_1309> targets = world.method_8390(class_1309.class, aoeBox, e -> e != this && !(e instanceof MossyStoneGolemEntity));
        for (class_1309 target : targets) {
            target.method_5643(this.method_48923().method_48812(this), 24.0f);
            double dx = target.method_23317() - impactX;
            double dz = target.method_23321() - impactZ;
            double dist = Math.max(0.1, Math.sqrt(dx * dx + dz * dz));
            target.method_5762((dx / dist) * 1.6, 0.65, (dz / dist) * 1.6);
            target.field_6037 = true;
        }
    }

    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_14959;
    }

    @Override
    protected class_3414 method_6002() {
        return class_3417.field_15055;
    }

    @Override
    protected void method_5712(class_2338 pos, class_2680 state) {
        this.method_5783(class_3417.field_15233, 1.2f, 0.65f);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movementController", 4, this::movementPredicate));
        controllers.add(new AnimationController<>(this, "attackController", 2, this::attackPredicate));
    }

    private PlayState movementPredicate(AnimationState<MossyStoneGolemEntity> event) {
        if (event.isMoving()) {
            return event.setAndContinue(RawAnimation.begin().thenLoop("animation.mossy_stone_golem.walk"));
        }
        return event.setAndContinue(RawAnimation.begin().thenLoop("animation.mossy_stone_golem.idle"));
    }

    private PlayState attackPredicate(AnimationState<MossyStoneGolemEntity> event) {
        if (this.method_6510()) {
            return event.setAndContinue(RawAnimation.begin().thenPlay("animation.mossy_stone_golem.attack"));
        }
        event.getController().forceAnimationReset();
        return PlayState.STOP;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    private static class SluggishBodyControl extends class_1330 {
        private final class_1308 mob;

        public SluggishBodyControl(class_1308 mob) {
            super(mob);
            this.mob = mob;
        }

        @Override
        public void method_6224() {
            // Smoothly interpolate bodyYaw towards headYaw at max ~2.2 degrees per tick
            float maxTurnSpeed = 2.2f;
            float diff = class_3532.method_15393(this.mob.field_6241 - this.mob.field_6283);
            this.mob.field_6283 += class_3532.method_15363(diff, -maxTurnSpeed, maxTurnSpeed);
            this.mob.method_36456(this.mob.field_6283);
        }
    }

    private static class GolemSlamAttackGoal extends class_1352 {
        private final MossyStoneGolemEntity golem;
        private int attackTicks = 0;
        private int cooldown = 0;

        public GolemSlamAttackGoal(MossyStoneGolemEntity golem) {
            this.golem = golem;
            this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
        }

        @Override
        public boolean method_6264() {
            if (this.cooldown > 0) {
                this.cooldown--;
                return false;
            }
            class_1309 target = this.golem.method_5968();
            if (target == null || !target.method_5805()) return false;
            return this.golem.method_5858(target) <= 20.0;
        }

        @Override
        public void method_6269() {
            this.attackTicks = 28;
            this.golem.method_19540(true);
            this.golem.method_5942().method_6340();
        }

        @Override
        public void method_6268() {
            class_1309 target = this.golem.method_5968();
            if (target != null) {
                this.golem.method_5988().method_6226(target, 15.0f, 15.0f);
            }
            this.attackTicks--;
            if (this.attackTicks == 14) {
                this.golem.performGroundSlam();
            }
        }

        @Override
        public boolean method_6266() {
            return this.attackTicks > 0;
        }

        @Override
        public void method_6270() {
            this.golem.method_19540(false);
            this.cooldown = 40;
        }
    }
}
