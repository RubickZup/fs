package net.mossystonegolem;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.mossystonegolem.entity.MossyStoneGolemEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MossyStoneGolemMod implements ModInitializer {
    public static final String MOD_ID = "mossystonegolem";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final class_1299<MossyStoneGolemEntity> MOSSY_STONE_GOLEM = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(MOD_ID, "mossy_stone_golem"),
            class_1299.class_1300.method_5903(MossyStoneGolemEntity::new, class_1311.field_6294)
                    .method_17687(1.95f, 2.2f)
                    .method_55687(1.8f)
                    .method_27299(10)
                    .build()
    );

    public static final class_1792 MOSSY_STONE_GOLEM_SPAWN_EGG = class_2378.method_10230(
            class_7923.field_41178,
            class_2960.method_60655(MOD_ID, "mossy_stone_golem_spawn_egg"),
            new class_1826(MOSSY_STONE_GOLEM, 0x4e5848, 0x30a891, new class_1792.class_1793())
    );

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Mossy Stone Golem Mod for Minecraft 1.21.1");
        FabricDefaultAttributeRegistry.register(MOSSY_STONE_GOLEM, MossyStoneGolemEntity.createAttributes());

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(entries -> {
            entries.method_45421(MOSSY_STONE_GOLEM_SPAWN_EGG);
        });
    }
}
