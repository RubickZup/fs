package net.mossystonegolem.client.renderer;

import net.minecraft.class_5617;
import net.mossystonegolem.client.model.MossyStoneGolemModel;
import net.mossystonegolem.entity.MossyStoneGolemEntity;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class MossyStoneGolemRenderer extends GeoEntityRenderer<MossyStoneGolemEntity> {
    public MossyStoneGolemRenderer(class_5617.class_5618 context) {
        super(context, new MossyStoneGolemModel());
        this.field_4673 = 1.6f;
    }
}
