package net.mossystonegolem.client.model;

import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.mossystonegolem.MossyStoneGolemMod;
import net.mossystonegolem.entity.MossyStoneGolemEntity;
import net.mossystonegolem.entity.VerletChain;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.model.GeoModel;

public class MossyStoneGolemModel extends GeoModel<MossyStoneGolemEntity> {
    private static final class_2960 MODEL = class_2960.method_60655(MossyStoneGolemMod.MOD_ID, "geo/mossy_stone_golem.geo.json");
    private static final class_2960 TEXTURE = class_2960.method_60655(MossyStoneGolemMod.MOD_ID, "textures/entity/mossy_stone_golem.png");
    private static final class_2960 ANIMATION = class_2960.method_60655(MossyStoneGolemMod.MOD_ID, "animations/mossy_stone_golem.animation.json");

    @Override
    public class_2960 getModelResource(MossyStoneGolemEntity animatable) {
        return MODEL;
    }

    @Override
    public class_2960 getTextureResource(MossyStoneGolemEntity animatable) {
        return TEXTURE;
    }

    @Override
    public class_2960 getAnimationResource(MossyStoneGolemEntity animatable) {
        return ANIMATION;
    }

    @Override
    public void setCustomAnimations(MossyStoneGolemEntity entity, long instanceId, AnimationState<MossyStoneGolemEntity> animationState) {
        super.setCustomAnimations(entity, instanceId, animationState);

        VerletChain chain = entity.chain;
        float bodyYawRad = (float) Math.toRadians(entity.field_6283);
        double cosYaw = Math.cos(-bodyYawRad);
        double sinYaw = Math.sin(-bodyYawRad);

        // Position and orient chain links 1..7 and bell_bone dynamically based on Verlet physics
        for (int i = 1; i < VerletChain.NODE_COUNT; i++) {
            String boneName = (i == 8) ? "bell_bone" : ("chain_" + i);
            GeoBone bone = this.getAnimationProcessor().getBone(boneName);
            if (bone == null) continue;

            class_243 curr = chain.getNodePos(i);
            class_243 prevNode = chain.getNodePos(i - 1);

            // World displacement from entity center
            double worldRelX = curr.field_1352 - entity.method_23317();
            double worldRelY = curr.field_1351 - entity.method_23318();
            double worldRelZ = curr.field_1350 - entity.method_23321();

            // Transform into entity-local space rotated by -bodyYaw
            double localX = worldRelX * cosYaw - worldRelZ * sinYaw;
            double localZ = worldRelX * sinYaw + worldRelZ * cosYaw;

            // Target in Blockbench coordinates (16 units/block, X axis inverted)
            float targetX = (float) (-localX * 16.0);
            float targetY = (float) (worldRelY * 16.0);
            float targetZ = (float) (localZ * 16.0);

            bone.setPosX(targetX - bone.getPivotX());
            bone.setPosY(targetY - bone.getPivotY());
            bone.setPosZ(targetZ - bone.getPivotZ());

            // Orient the bone to follow the link direction
            double dirX = curr.field_1352 - prevNode.field_1352;
            double dirY = curr.field_1351 - prevNode.field_1351;
            double dirZ = curr.field_1350 - prevNode.field_1350;
            double hDist = Math.sqrt(dirX * dirX + dirZ * dirZ);

            if (hDist > 1.0E-4 || Math.abs(dirY) > 1.0E-4) {
                float pitch = (float) Math.atan2(dirY, hDist);
                double localDirX = dirX * cosYaw - dirZ * sinYaw;
                double localDirZ = dirX * sinYaw + dirZ * cosYaw;
                float yaw = (float) Math.atan2(localDirX, localDirZ);

                bone.setRotX(pitch);
                bone.setRotY(yaw);
            }
        }
    }
}
