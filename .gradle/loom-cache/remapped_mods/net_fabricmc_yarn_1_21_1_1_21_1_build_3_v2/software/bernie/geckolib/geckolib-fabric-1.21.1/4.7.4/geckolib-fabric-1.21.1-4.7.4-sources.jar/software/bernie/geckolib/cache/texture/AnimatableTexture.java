package software.bernie.geckolib.cache.texture;

import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.blaze3d.systems.RenderCall;
import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.ints.IntSet;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.util.RenderUtil;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.resource.metadata.AnimationResourceMetadata;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.ResourceTexture;
import net.minecraft.client.texture.SpriteDimensions;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/**
 * Wrapper for {@link ResourceTexture SimpleTexture} implementation allowing for casual use of animated non-atlas textures
 */
public class AnimatableTexture extends ResourceTexture {
	protected AnimationContents animationContents = null;
	protected int glowMaskId = -1;
	protected boolean isAnimated = false;

	public AnimatableTexture(final Identifier location) {
		super(location);
	}

	@Override
	public void load(ResourceManager manager) throws IOException {
		Resource resource = manager.getResourceOrThrow(this.location);
		AnimationResourceMetadata animMeta = resource.getMetadata().decode(AnimationResourceMetadata.READER).orElse(null);

		if (animMeta != null) {
			NativeImage nativeImage;

			try (InputStream inputstream = resource.getInputStream()) {
				nativeImage = NativeImage.read(inputstream);
			}

			this.animationContents = new AnimationContents(nativeImage, animMeta);

			if (!this.animationContents.isValid()) {
				nativeImage.close();

				return;
			}

			this.isAnimated = true;

			onRenderThread(() -> {
				TextureUtil.prepareImage(getGlId(), 0, this.animationContents.frameSize.width(), this.animationContents.frameSize.height());
				nativeImage.upload(0, 0, 0, 0, 0, this.animationContents.frameSize.width(), this.animationContents.frameSize.height(), false, false);
			});
		}
	}

	/**
	 * Returns whether the texture found any valid animation metadata when loading.
	 * <p>
	 * If false, then this is no different to a standard {@link ResourceTexture}
	 */
	public boolean isAnimated() {
		return this.isAnimated;
	}

	public static void setAndUpdate(Identifier texturePath) {
		setAndUpdate(texturePath, (int) RenderUtil.getCurrentTick());
	}

	/**
	 * Setting a specific frame for the animated texture does not work well because of how Minecraft buffers rendering passes
	 * <p>
	 * Use the non-specified method above unless you know what you're doing
	 */
	public static void setAndUpdate(Identifier texturePath, int frameTick) {
		AbstractTexture texture = MinecraftClient.getInstance().getTextureManager().getTexture(texturePath);

		if (texture instanceof AnimatableTexture animatableTexture)
			animatableTexture.setAnimationFrame(frameTick);

		RenderSystem.setShaderTexture(0, texture.getGlId());
	}

	public void setAnimationFrame(int tick) {
		if (this.animationContents != null && this.animationContents.animatedTexture != null)
			this.animationContents.animatedTexture.setCurrentFrame(tick);
	}

	private static void onRenderThread(RenderCall renderCall) {
		if (!RenderSystem.isOnRenderThread()) {
			RenderSystem.recordRenderCall(renderCall);
		}
		else {
			renderCall.execute();
		}
	}

	protected class AnimationContents {
		protected final SpriteDimensions frameSize;
		protected final Texture animatedTexture;

		private AnimationContents(NativeImage image, AnimationResourceMetadata animMeta) {
			this.frameSize = animMeta.getSize(image.getWidth(), image.getHeight());
			this.animatedTexture = generateAnimatedTexture(image, animMeta);
		}

		private boolean isValid() {
			return this.animatedTexture != null;
		}

		private Texture generateAnimatedTexture(NativeImage image, AnimationResourceMetadata animMeta) {
			if (!MathHelper.isMultipleOf(image.getWidth(), this.frameSize.width()) || !MathHelper.isMultipleOf(image.getHeight(), this.frameSize.height())) {
				GeckoLibConstants.LOGGER.error("Image {} size {},{} is not multiple of frame size {},{}", AnimatableTexture.this.location, image.getWidth(), image.getHeight(), this.frameSize.width(), this.frameSize.height());

				return null;
			}

			int columns = image.getWidth() / this.frameSize.width();
			int rows = image.getHeight() / this.frameSize.height();
			int frameCount = columns * rows;
			List<Frame> frames = new ObjectArrayList<>();

			animMeta.forEachFrame((frame, frameTime) -> frames.add(new Frame(frame, frameTime)));

			if (frames.isEmpty()) {
				for (int frame = 0; frame < frameCount; ++frame) {
					frames.add(new Frame(frame, animMeta.getDefaultFrameTime()));
				}
			}
			else {
				int index = 0;
				IntSet unusedFrames = new IntOpenHashSet();

				for (Frame frame : frames) {
					if (frame.time <= 0) {
						GeckoLibConstants.LOGGER.warn("Invalid frame duration on sprite {} frame {}: {}", AnimatableTexture.this.location, index, frame.time);
						unusedFrames.add(frame.index);
					}
					else if (frame.index < 0 || frame.index >= frameCount) {
						GeckoLibConstants.LOGGER.warn("Invalid frame index on sprite {} frame {}: {}", AnimatableTexture.this.location, index, frame.index);
						unusedFrames.add(frame.index);
					}

					index++;
				}

				if (!unusedFrames.isEmpty())
					GeckoLibConstants.LOGGER.warn("Unused frames in sprite {}: {}", AnimatableTexture.this.location, Arrays.toString(unusedFrames.toArray()));
			}

			return frames.size() <= 1 ? null : new Texture(image, frames.toArray(new Frame[0]), columns, animMeta.shouldInterpolate());
		}

		protected record Frame(int index, int time) {}

		protected class Texture implements AutoCloseable {
			protected final NativeImage baseImage;
			protected final Frame[] frames;
			protected final int framePanelSize;
			protected final boolean interpolating;
			protected final NativeImage interpolatedFrame;
			protected final int totalFrameTime;

			protected int currentFrame;
			protected int currentSubframe;

			private Texture(NativeImage baseImage, Frame[] frames, int framePanelSize, boolean interpolating) {
				this.baseImage = baseImage;
				this.frames = frames;
				this.framePanelSize = framePanelSize;
				this.interpolating = interpolating;
				this.interpolatedFrame = interpolating ? new NativeImage(AnimationContents.this.frameSize.width(), AnimationContents.this.frameSize.height(), false) : null;
				int time = 0;

				for (Frame frame : this.frames) {
					time += frame.time;
				}

				this.totalFrameTime = time;
			}

			private int getFrameX(int frameIndex) {
				return frameIndex % this.framePanelSize;
			}

			private int getFrameY(int frameIndex) {
				return frameIndex / this.framePanelSize;
			}

			public void setCurrentFrame(int ticks) {
				ticks %= this.totalFrameTime;

				if (ticks == this.currentSubframe)
					return;

				int lastSubframe = this.currentSubframe;
				int lastFrame = this.currentFrame;
				int time = 0;

				for (Frame frame : this.frames) {
					time += frame.time;

					if (ticks < time) {
						this.currentFrame = frame.index;
						this.currentSubframe = ticks % frame.time;

						break;
					}
				}

				if (this.currentFrame != lastFrame && this.currentSubframe == 0) {
					onRenderThread(() -> {
						TextureUtil.prepareImage(getTextureIdToUpload(), 0, AnimationContents.this.frameSize.width(), AnimationContents.this.frameSize.height());
						this.baseImage.upload(0, 0, 0, getFrameX(this.currentFrame) * AnimationContents.this.frameSize.width(), getFrameY(this.currentFrame) * AnimationContents.this.frameSize.height(), AnimationContents.this.frameSize.width(), AnimationContents.this.frameSize.height(), false, false);
					});
				}
				else if (this.currentSubframe != lastSubframe && this.interpolating) {
					onRenderThread(this::generateInterpolatedFrame);
				}
			}

			private void generateInterpolatedFrame() {
				Frame frame = this.frames[this.currentFrame];
				double frameProgress = 1 - (double)this.currentSubframe / (double)frame.time;
				int nextFrameIndex = this.frames[(this.currentFrame + 1) % this.frames.length].index;

				if (frame.index != nextFrameIndex) {
					for (int y = 0; y < this.interpolatedFrame.getHeight(); ++y) {
						for (int x = 0; x < this.interpolatedFrame.getWidth(); ++x) {
							int prevFramePixel = getPixel(frame.index, x, y);
							int nextFramePixel = getPixel(nextFrameIndex, x, y);
							int blendedRed = interpolate(frameProgress, prevFramePixel >> 16 & 255, nextFramePixel >> 16 & 255);
							int blendedGreen = interpolate(frameProgress, prevFramePixel >> 8 & 255, nextFramePixel >> 8 & 255);
							int blendedBlue = interpolate(frameProgress, prevFramePixel & 255, nextFramePixel & 255);

							this.interpolatedFrame.setColor(x, y, prevFramePixel & -16777216 | blendedRed << 16 | blendedGreen << 8 | blendedBlue);
						}
					}

					TextureUtil.prepareImage(getTextureIdToUpload(), 0, AnimationContents.this.frameSize.width(), AnimationContents.this.frameSize.height());
					this.interpolatedFrame.upload(0, 0, 0, 0, 0, AnimationContents.this.frameSize.width(), AnimationContents.this.frameSize.height(), false, false);
				}
			}

			private int getPixel(int frameIndex, int x, int y) {
				return this.baseImage.getColor(x + getFrameX(frameIndex) * AnimationContents.this.frameSize.width(), y + getFrameY(frameIndex) * AnimationContents.this.frameSize.height());
			}

			private int interpolate(double frameProgress, double prevColor, double nextColor) {
				return (int)(frameProgress * prevColor + (1 - frameProgress) * nextColor);
			}

			private int getTextureIdToUpload() {
				return AnimatableTexture.this.glowMaskId == -1 ? AnimatableTexture.this.getGlId() : AnimatableTexture.this.glowMaskId;
			}

			@Override
			public void close() {
				this.baseImage.close();

				if (this.interpolatedFrame != null)
					this.interpolatedFrame.close();
			}
		}
	}
}
